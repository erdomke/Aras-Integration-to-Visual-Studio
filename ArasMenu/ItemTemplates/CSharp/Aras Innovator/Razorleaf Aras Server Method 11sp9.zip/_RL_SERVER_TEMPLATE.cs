﻿using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.SessionState;
using System.Globalization;
using Aras.IOM;

namespace $safeitemname$_class {
	class $safeitemname$_class : Item {
		public $safeitemname$_class() : base(null) { }

		public Item $safeitemname$() {
			//NOTE: This is system defined by Innovator and will be available when below is pasted into Innovator.
			Aras.Server.Core.CallContext CCO = ( ( Aras.Server.Core.IOMConnection )serverConnection ).CCO;
			Aras.Server.Core.IContextState RequestState = CCO.RequestState;

			// _________________Cut below this line to paste into Innovator________________________
			#region $safeitemname$
			
			/* *****************************************************************************
			Method Name:			$safeitemname$
			Client Name:			
			Created By/Company:		$username$ 
			Creation Date:			YYYY-MM-DD
			Description:
				<Description of the method>
			
			Hooks:
				Type:		<associated ItemType>
				Event:		<event hook description>
				Called by:	<Parent functions>
			
			Inputs:
				<describe the inputs expected by the server method>
			
			Revisions:
				Rev Date		Modified By			Description
				YYYY-MM-DD		***					Initial creation
			***************************************************************************** */

			//WARNING: DO NOT FORGET TO DISABLE THIS IN A PRODUCTION ENVIRONMENT!!!
			//if(System.Diagnostics.Debugger.Launch()) System.Diagnostics.Debugger.Break();	//enable/disable the debugger as required

			string MethodName = "$safeitemname$";

			//***** GRANT IDENTITY PRIVILEGES
			//grantIdentityPrivileges("Aras PLM");	// If this is enabled always revoke the privileges in the Finally below.
			//*******************************
	
			Item result = this;		// default return value.
				
			try {
	
				//****************************************
				// Insert code here...
	
	
				// Set result if 'this' is not the required return value.
				// result = ?
				//****************************************
	
					
			}
			//throw ArgumentExceptions for errors which are anticipated, such as validating a user has updated certain properties
			//error is plainly presented to the user
			catch (System.ArgumentException argex) {
				result = inn.newError(argex.Message);
				//result.setErrorCode("0");		//only use if this method is called from another method
			}
			//throw ApplicationExceptions for any other errors which are checked for in code, such as when a query returns an error item
			//error is presented with a bold header including the methodname
			catch (System.ApplicationException appex) {
				result = inn.newError(string.Format("<b>ERROR in method {0}</b><br>{1}", MethodName, appex.Message));
				//result.setErrorCode("0");		//only use if this method is called from another method
			}
			//catch any other unexpected exceptions
			//error is presented with a bold header including the methodname
			//catch (System.Exception ex){
			//	result = inn.newError(string.Format("<b>SYSTEM EXCEPTION in method {0}</b><br>{1}", MethodName, ex.Message));
			////result.setErrorCode("0");		//only use if this method is called from another method
			//}
			finally {
				//**** REVOKE IDENTITY PRIVILEGES
				//revokeIdentityPrivileges();
				//*******************************
			}
	
			return result;
		}
	
		// _____ Custom helper functions _____
	
	
		// _____ Razorleaf Template Members and helper functions _____
		#region "Innovator inn;"
	
		private Innovator _inn;
		public Innovator inn {
			get {
				if(_inn == null)
					_inn = this.getInnovator();
				return _inn;
			}
		}
	
		#endregion
			

		#region "Identity Privileges"
		/// <summary>
		/// This section is to allow the current method to assume the privileges of a specific identity.
		/// For instance calling: grantIdentityPrivileges("Aras PLM"); will allow this method all of the
		/// rights of the Aras PLM identity.
		/// The revokeIdentityPrivileges() method will removed the privileges added for this method. It
		/// must be called from before the method exits. Most likely in the Finally of the main method code.
		/// If different identity privileges must be granted a second time within the same method, first use
		/// revokeIdentityPrivileges() to remove the first privileges before granting new ones.
		/// </summary>
	
		private string AssignedIdentity;
			
		/// <summary>
		/// If required, call this helper function to run this method as another Identity. 
		/// Ensure that you call the revokeIdentityPrivileges helper function in the 
		/// finally block to revoke the Identity privilege when this method completes.
		/// </summary>
		public void grantIdentityPrivileges( string assignedIdent ) {
			if (!string.IsNullOrEmpty(AssignedIdentity)) {
				revokeIdentityPrivileges();
			}
	
			Aras.Server.Security.Identity secIdentity = Aras.Server.Security.Identity.GetByName(assignedIdent);
			if(Aras.Server.Security.Permissions.GrantIdentity(secIdentity)) {
				AssignedIdentity = assignedIdent;
			} 
		}
	
		/// <summary>
		/// If you granted security privileges, then you need to ensure that you revoke the privilege.
		/// </summary>
		public void revokeIdentityPrivileges() {
						if( AssignedIdentity != null ) {
							Aras.Server.Security.Permissions.RevokeIdentity(Aras.Server.Security.Identity.GetByName(AssignedIdentity));
							AssignedIdentity = null;
						} 
		}
	
		#endregion
	
		private void end_of_method_() {
		#endregion 

		// __________Cut Above this line and paste into Innovator Method editor __________
		// This method must not be closed when it is pasted into Innovator!
		}
	}
}