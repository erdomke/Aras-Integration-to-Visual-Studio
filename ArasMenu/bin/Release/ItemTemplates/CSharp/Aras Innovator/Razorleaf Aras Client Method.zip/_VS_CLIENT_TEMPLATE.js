﻿// _________________Cut below this line to paste into Innovator________________________

/* *****************************************************************************
Method Name:			$safeitemname$
Client Name:			Client_Name
Created By/Company:		$username$ 
Creation Date:			YYYY-MM-DD
Description:
	<Description of the method>
	
Hooks:
	Type:	<associated ItemType>
	Event:	<event hook description>
	
Inputs:
	<describe the inputs expected by the server method>
	
Revisions:
	Rev Date		Modified By			Description
	YYYY-MM-DD		$username$			Initial creation
***************************************************************************** */

//debugger;

// __________Cut Above this line and paste into Innovator Method editor __________